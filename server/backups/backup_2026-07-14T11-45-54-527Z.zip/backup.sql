-- E-Serbisyo Database Backup
-- Generated: 2026-07-14T11:45:54.527Z

SET FOREIGN_KEY_CHECKS = 0;

-- -----------------------------------------------------
-- Table Structure for `tbl_announcements`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tbl_announcements`;
CREATE TABLE `tbl_announcements` (
  `announcement_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `target_audience` enum('All','Residents','Officials') DEFAULT 'All',
  `content_body` text NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `is_pinned` tinyint(1) DEFAULT 0,
  `status` enum('Draft','Pending Approval','Published','Archived') DEFAULT 'Draft',
  `date_posted` datetime DEFAULT current_timestamp(),
  `expiry_date` datetime DEFAULT NULL,
  `posted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`announcement_id`),
  KEY `posted_by` (`posted_by`),
  CONSTRAINT `tbl_announcements_ibfk_1` FOREIGN KEY (`posted_by`) REFERENCES `tbl_barangayofficials` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data Dump for `tbl_announcements`
INSERT INTO `tbl_announcements` VALUES 
(1, 'Road Clearing Operations', 'All', 'Please be advised that road clearing will start on Monday.', NULL, 1, 'Published', '2026-02-24 09:24:55', '2026-03-03 09:24:55', NULL),
(2, 'Free Medical Mission', 'All', 'Join us at the covered court this weekend for free checkups!', NULL, 0, 'Published', '2026-02-24 09:24:55', '2026-02-27 09:24:55', NULL),
(4, 'Test', 'All', 'Testing Malunggay Pandesal|||LINK|||google.com', NULL, 0, 'Published', '2026-03-27 09:44:06', NULL, 3),
(5, 'Finding Domain', 'All', 'pls domain, penge', '/uploads/announcements/announcement_1784015377324-667438028.png', 1, 'Published', '2026-07-14 07:49:37', NULL, 3);

-- -----------------------------------------------------
-- Table Structure for `tbl_auditlogs`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tbl_auditlogs`;
CREATE TABLE `tbl_auditlogs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `table_affected` varchar(100) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `action_type` varchar(100) NOT NULL,
  `old_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_value`)),
  `new_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_value`)),
  `timestamp` datetime DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_type` enum('Resident','Official','System') NOT NULL,
  `outcome` enum('success','failure') NOT NULL DEFAULT 'success',
  `user_agent` text DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_action` (`action_type`),
  KEY `idx_outcome` (`outcome`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data Dump for `tbl_auditlogs`
INSERT INTO `tbl_auditlogs` VALUES 
(1, 1, 'tbl_BarangayOfficials', 2, 'official.create', NULL, '{"official_id":"SEC-001","username":"johndoe","role":"Secretary"}', '2026-02-24 12:38:04', '::1', 'Official', 'success', NULL),
(2, 1, 'tbl_BarangayOfficials', 2, 'document.status_change', '{"account_status":"Active"}', '{"account_status":"Inactive"}', '2026-02-24 12:38:13', '::1', 'Official', 'success', NULL),
(3, 1, 'tbl_BarangayOfficials', 2, 'document.status_change', '{"account_status":"Inactive"}', '{"account_status":"Suspended"}', '2026-02-24 12:38:16', '::1', 'Official', 'success', NULL),
(4, 1, 'tbl_BarangayOfficials', 2, 'document.status_change', '{"account_status":"Suspended"}', '{"account_status":"Active"}', '2026-02-24 12:38:18', '::1', 'Official', 'success', NULL),
(5, 1, 'tbl_BarangayOfficials', 3, 'official.create', NULL, '{"official_id":"CAP-001","username":"marias","role":"Captain"}', '2026-03-22 12:43:44', '::1', 'Official', 'success', NULL),
(6, 3, 'Pending', 0, 'document.status_change', '{"status":"Admin Approveed request REQ-20260327-2283"}', '{}', '2026-03-27 08:19:29', '0.0.0.0', '', 'success', NULL),
(7, 3, 'tbl_Payments', 100, 'payment.encode', NULL, '{"amount":"OR-1","or_number":"Payment received for REQ-20260327-2283","encoded_at":"2026-03-27T08:42:16.961Z"}', '2026-03-27 08:42:16', '0.0.0.0', '', 'success', NULL),
(8, 3, 'tbl_Payments', 100, 'payment.encode', NULL, '{"amount":"OR1","or_number":"Payment received for REQ-20260327-2283","encoded_at":"2026-03-27T08:50:15.196Z"}', '2026-03-27 08:50:15', '0.0.0.0', '', 'success', NULL),
(9, 3, 'tbl_BarangayOfficials', 2, 'document.status_change', '{"account_status":"Active"}', '{"account_status":"Inactive"}', '2026-04-16 08:26:03', '::1', 'Official', 'success', NULL),
(10, 3, 'tbl_BarangayOfficials', 2, 'document.status_change', '{"account_status":"Inactive"}', '{"account_status":"Active"}', '2026-04-16 08:26:05', '::1', 'Official', 'success', NULL),
(11, 3, 'tbl_BarangayOfficials', 4, 'official.create', NULL, '{"official_id":"wehufiouawebgfi","username":"tester","role":"Admin"}', '2026-04-16 08:54:05', '::1', 'Official', 'success', NULL),
(12, 3, 'tbl_BarangayOfficials', 2, 'document.status_change', '{"account_status":"Active"}', '{"account_status":"Inactive"}', '2026-04-29 15:19:35', '::1', 'Official', 'success', NULL),
(13, 3, 'tbl_BarangayOfficials', 2, 'document.status_change', '{"account_status":"Inactive"}', '{"account_status":"Active"}', '2026-04-29 15:19:39', '::1', 'Official', 'success', NULL),
(14, 3, 'Pending', 0, 'document.status_change', '{"status":"Admin Approveed request REQ-20260617-9658"}', '{}', '2026-06-17 11:11:24', '0.0.0.0', '', 'success', NULL),
(15, 3, 'Pending', 0, 'document.status_change', '{"status":"Admin Approveed request REQ-20260617-9848"}', '{}', '2026-06-17 11:15:56', '0.0.0.0', '', 'success', NULL),
(16, 3, 'tbl_Payments', 5, 'payment.encode', NULL, '{"amount":0,"or_number":"EXEMPT-1784014372882","encoded_at":"2026-07-14T07:32:52.897Z"}', '2026-07-14 07:32:52', '127.0.0.1', 'Official', 'success', NULL),
(17, 3, 'tbl_Requests', 5, 'document.status_change', '{"status":"For Payment"}', '{"status":"Processing"}', '2026-07-14 07:32:52', '127.0.0.1', 'Official', 'success', NULL),
(18, 3, 'tbl_Requests', 5, 'document.print', NULL, '{"reference_no":"REQ-20260617-9848","printed_at":"2026-07-14T07:33:18.853Z"}', '2026-07-14 07:33:18', '127.0.0.1', 'Official', 'success', NULL),
(19, 3, 'tbl_Requests', 5, 'document.print', NULL, '{"reference_no":"REQ-20260617-9848","printed_at":"2026-07-14T07:33:27.217Z"}', '2026-07-14 07:33:27', '127.0.0.1', 'Official', 'success', NULL),
(20, 3, 'tbl_Requests', 5, 'document.print', NULL, '{"reference_no":"REQ-20260617-9848","printed_at":"2026-07-14T07:48:28.680Z"}', '2026-07-14 07:48:28', '127.0.0.1', 'Official', 'success', NULL),
(21, 3, 'tbl_Requests', 5, 'document.print', NULL, '{"reference_no":"REQ-20260617-9848","printed_at":"2026-07-14T08:06:03.568Z"}', '2026-07-14 08:06:03', '127.0.0.1', 'Official', 'success', NULL),
(22, 3, 'tbl_Requests', 5, 'document.status_change', '{"status":"Processing"}', '{"status":"Ready for Pickup"}', '2026-07-14 08:22:32', '127.0.0.1', 'Official', 'success', NULL),
(23, 3, 'tbl_Requests', 5, 'document.status_change', '{"status":"Ready for Pickup"}', '{"status":"Issued"}', '2026-07-14 08:22:41', '127.0.0.1', 'Official', 'success', NULL),
(24, 3, 'tbl_Residents', 7, 'registration.reject', '{"account_status":"Pending"}', '{"account_status":"Blocked","rejection_reason":"walang pic\\n"}', '2026-07-14 09:14:26', '0.0.0.0', 'Official', 'success', NULL),
(25, 3, 'tbl_Requests', 8, 'document.status_change', '{"status":"Pending"}', '{"status":"For Payment"}', '2026-07-14 09:51:26', '127.0.0.1', 'Official', 'success', NULL),
(26, 3, 'tbl_Payments', 8, 'payment.encode', NULL, '{"amount":0,"or_number":"1234059080","encoded_at":"2026-07-14T10:03:59.147Z"}', '2026-07-14 10:03:59', '127.0.0.1', 'Official', 'success', NULL),
(27, 3, 'tbl_Requests', 8, 'document.status_change', '{"status":"For Payment"}', '{"status":"Processing"}', '2026-07-14 10:03:59', '127.0.0.1', 'Official', 'success', NULL),
(28, 3, 'tbl_Requests', 8, 'document.print', NULL, '{"reference_no":"REQ-20260714-3379","printed_at":"2026-07-14T10:04:15.684Z"}', '2026-07-14 10:04:15', '127.0.0.1', 'Official', 'success', NULL),
(29, 3, 'tbl_Requests', 8, 'document.status_change', '{"status":"Processing"}', '{"status":"Ready for Pickup"}', '2026-07-14 10:04:40', '127.0.0.1', 'Official', 'success', NULL),
(30, 3, 'tbl_Requests', 8, 'document.status_change', '{"status":"Ready for Pickup"}', '{"status":"Issued"}', '2026-07-14 10:05:18', '127.0.0.1', 'Official', 'success', NULL),
(31, 3, 'tbl_SystemSettings', NULL, 'system.backup', NULL, '{"filename":"backup_2026-07-14T10-27-38-148Z.zip"}', '2026-07-14 10:27:38', '127.0.0.1', 'Official', 'success', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'),
(32, 3, 'tbl_DigitalSignatures', 3, 'document.signature_upload', NULL, '{"filename":"sig_3_1784024909303.png.enc"}', '2026-07-14 10:28:29', '127.0.0.1', 'Official', 'success', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'),
(33, 3, 'tbl_Requests', 9, 'requests.status_change', '{"status":"Pending"}', '{"status":"For Payment"}', '2026-07-14 10:30:26', '127.0.0.1', 'Official', 'success', NULL),
(34, 3, 'tbl_Payments', 9, 'payment.exempt', NULL, '{"amount":"0","or_number":"123456789","encoded_at":"2026-07-14T10:30:48.345Z"}', '2026-07-14 10:30:48', '127.0.0.1', 'Official', 'success', NULL),
(35, 3, 'tbl_Requests', 9, 'requests.status_change', '{"status":"For Payment"}', '{"status":"Processing"}', '2026-07-14 10:30:48', '127.0.0.1', 'Official', 'success', NULL),
(36, 3, 'tbl_Requests', 9, 'document.print', NULL, '{"reference_no":"WLK-20260714-9713","printed_at":"2026-07-14T10:30:55.628Z"}', '2026-07-14 10:30:55', '127.0.0.1', 'Official', 'success', NULL),
(37, 3, 'tbl_Requests', 10, 'requests.status_change', '{"status":"Pending"}', '{"status":"For Payment"}', '2026-07-14 10:31:50', '127.0.0.1', 'Official', 'success', NULL),
(38, 10, 'auth', 10, 'user.login', NULL, '{"login_time":"2026-07-14T10:32:13.803Z"}', '2026-07-14 10:32:13', '127.0.0.1', 'Resident', 'success', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'),
(39, 10, 'tbl_Requests', 11, 'request.create', NULL, '{"reference_no":"REQ-20260714-9352","doc_type_id":"3","purpose":"idawubdauwb"}', '2026-07-14 10:32:57', '127.0.0.1', 'Resident', 'success', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'),
(40, 3, 'auth', 3, 'user.login', NULL, '{"login_time":"2026-07-14T10:33:10.731Z"}', '2026-07-14 10:33:10', '127.0.0.1', 'Official', 'success', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'),
(41, 3, 'tbl_BarangayOfficials', 4, 'official.status_change', '{"account_status":"Active"}', '{"account_status":"Inactive"}', '2026-07-14 10:34:10', '127.0.0.1', 'Official', 'success', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'),
(42, 3, 'tbl_BarangayOfficials', 4, 'official.status_change', '{"account_status":"Inactive"}', '{"account_status":"Active"}', '2026-07-14 10:34:12', '127.0.0.1', 'Official', 'success', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'),
(43, 3, 'tbl_SystemSettings', NULL, 'system.settings_update', NULL, '{"setting_key":"barangay_name","setting_value":"Barangay Malaya"}', '2026-07-14 10:43:25', '127.0.0.1', 'Official', 'success', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'),
(44, 10, 'auth', 10, 'user.login', NULL, '{"login_time":"2026-07-14T11:45:34.160Z"}', '2026-07-14 11:45:34', '127.0.0.1', 'Resident', 'success', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'),
(45, 3, 'auth', 3, 'user.login', NULL, '{"login_time":"2026-07-14T11:45:42.347Z"}', '2026-07-14 11:45:42', '127.0.0.1', 'Official', 'success', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36');

-- -----------------------------------------------------
-- Table Structure for `tbl_barangayofficials`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tbl_barangayofficials`;
CREATE TABLE `tbl_barangayofficials` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `official_id` varchar(50) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email_official` varchar(255) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('Super Admin','Admin','Secretary','Treasurer','Captain') NOT NULL,
  `account_status` enum('Active','Inactive','Suspended') DEFAULT 'Active',
  `require_password_change` tinyint(1) DEFAULT 1,
  `auth_token` varchar(255) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `official_id` (`official_id`),
  UNIQUE KEY `email_official` (`email_official`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data Dump for `tbl_barangayofficials`
INSERT INTO `tbl_barangayofficials` VALUES 
(1, 'SA-001', 'System Administrator', 'admin@eserbisyo.com', 'superadmin', '0eeaa9fdda267f5bf6f0b4fe2fabb4133c1b8689d02832052fb90d129ea3093f', 'Super Admin', 'Active', 0, NULL, '2026-03-22 12:43:18'),
(2, 'SEC-001', 'John Doe', 'john@brgy.gov.ph', 'johndoe', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'Secretary', 'Active', 1, NULL, NULL),
(3, 'CAP-001', 'Maria Santos', 'admin1@brgy.gov.ph', 'marias', 'ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f', 'Captain', 'Active', 0, NULL, '2026-07-14 11:45:42'),
(4, 'wehufiouawebgfi', 'Meow', 'test1@official.com', 'tester', '24134886902804bd7753fe5d693574553fac08acc67b2f2f196428855fd78740', 'Admin', 'Active', 1, NULL, '2026-04-16 09:19:45');

-- -----------------------------------------------------
-- Table Structure for `tbl_digitalsignatures`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tbl_digitalsignatures`;
CREATE TABLE `tbl_digitalsignatures` (
  `signature_id` int(11) NOT NULL AUTO_INCREMENT,
  `official_id` int(11) NOT NULL,
  `signature_blob` varchar(255) NOT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `checksum` varchar(255) DEFAULT NULL,
  `encryption_key` varchar(255) DEFAULT NULL,
  `status` enum('Active','Revoked') DEFAULT 'Active',
  `uploaded_at` datetime DEFAULT current_timestamp(),
  `expiry_date` datetime DEFAULT NULL,
  PRIMARY KEY (`signature_id`),
  KEY `official_id` (`official_id`),
  CONSTRAINT `tbl_digitalsignatures_ibfk_1` FOREIGN KEY (`official_id`) REFERENCES `tbl_barangayofficials` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data Dump for `tbl_digitalsignatures`
INSERT INTO `tbl_digitalsignatures` VALUES 
(1, 3, 'sig_3_1784024909303.png.enc', NULL, NULL, NULL, 'Active', '2026-07-14 10:28:29', NULL);

-- -----------------------------------------------------
-- Table Structure for `tbl_documenttypes`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tbl_documenttypes`;
CREATE TABLE `tbl_documenttypes` (
  `doc_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `base_fee` decimal(10,2) DEFAULT 0.00,
  `requirements` text DEFAULT NULL,
  `template_file` varchar(255) DEFAULT NULL,
  `layout_config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`layout_config`)),
  `paper_size` varchar(50) DEFAULT 'A4',
  `validity_days` int(11) DEFAULT 180,
  `is_available` tinyint(1) DEFAULT 1,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`doc_type_id`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `tbl_documenttypes_ibfk_1` FOREIGN KEY (`updated_by`) REFERENCES `tbl_barangayofficials` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data Dump for `tbl_documenttypes`
INSERT INTO `tbl_documenttypes` VALUES 
(1, 'Barangay Clearance', 'Used for employment and general purposes.', '50.00', 'Valid ID, 1x1 Picture', 'template_1_1776335114347-327187567.png.enc', '{"name":{"x":255,"y":324},"purpose":{"x":251,"y":490},"signature":{"x":388,"y":558},"qr":{"x":426,"y":748},"reference":{"x":50,"y":800}}', 'A4', 180, 1, 3, '2026-04-16 12:44:06'),
(2, 'Certificate of Indigency', 'Used for scholarship and financial aid. Free of charge.', '0.00', 'Proof of Income or Valid ID', 'template_2_1784015249397-287610592.png.enc', '{"name":{"x":280,"y":291},"purpose":{"x":105,"y":451},"signature":{"x":230,"y":467},"qr":{"x":469,"y":731},"reference":{"x":446,"y":828}}', 'A4', 180, 1, 3, '2026-07-14 07:48:09'),
(3, 'Business Permit', NULL, '150.00', 'DTI Registration, Lease Contract', NULL, NULL, 'A4', 180, 1, 1, '2026-02-24 09:36:45');

-- -----------------------------------------------------
-- Table Structure for `tbl_emailverification`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tbl_emailverification`;
CREATE TABLE `tbl_emailverification` (
  `verification_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `token_hash` varchar(255) NOT NULL,
  `ip_request` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `is_verified` tinyint(1) DEFAULT 0,
  `verified_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`verification_id`),
  KEY `email` (`email`),
  KEY `token_hash` (`token_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data Dump for `tbl_emailverification`
INSERT INTO `tbl_emailverification` VALUES 
(1, 10, 'morales.johnrey@gmail.com', '67c201733ef0e5fba7396fdc12fb3fd32b18515fa145940738590917db5fba70', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-14 10:34:13', 1, '2026-07-14 09:34:35', '2026-07-14 09:34:13');

-- -----------------------------------------------------
-- Table Structure for `tbl_passwordreset`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tbl_passwordreset`;
CREATE TABLE `tbl_passwordreset` (
  `reset_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token_hash` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `ip_request` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `attempt_count` int(11) DEFAULT 0,
  `is_used` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`reset_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data Dump for `tbl_passwordreset`
INSERT INTO `tbl_passwordreset` VALUES 
(1, 1, '96459d18171216cba4f5832f19826c8308f07197e867d0326099aca58e086826', 'test@gmail.com', '127.0.0.1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-PH) WindowsPowerShell/5.1.26100.8655', '2026-07-14 07:59:53', 0, 0, '2026-07-14 06:59:53'),
(2, 2, '68b1796e3800878293ee831741b3c2780b0476efee5148e57d805dede7f50557', 'test1@gmail.com', '127.0.0.1', 'Unknown', '2026-07-14 08:09:20', 0, 0, '2026-07-14 07:09:20'),
(3, 2, 'e5241e24f000ebdc0c29a936dec338285d8386dee228376827bf71f9593d2c27', 'test1@gmail.com', '127.0.0.1', 'Unknown', '2026-07-14 08:11:58', 0, 0, '2026-07-14 07:11:58'),
(4, 7, 'a9304e3951c44f098df3bc38d5129007ead9905311f646c6a01fe1c2b5d6f084', 'morales.johnrey@gmail.com', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-14 08:18:59', 0, 0, '2026-07-14 07:18:59'),
(5, 7, 'f9d36e51c7f8d8a10656960bf5844e796d9a14cd2b5301409d31bed6c2591c0e', 'morales.johnrey@gmail.com', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-14 09:23:48', 0, 0, '2026-07-14 08:23:48'),
(6, 7, '04d72916f882a3bdb9c3a8ed3af600136af82f2471f7bc86bf05aae814bf0423', 'morales.johnrey@gmail.com', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-14 09:30:38', 0, 0, '2026-07-14 08:30:38'),
(7, 7, 'ab6401bf4c6333b71a7dde87548ef8200d3b8121e5db04fbc02e27d8ddda4b5d', 'morales.johnrey@gmail.com', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-14 10:12:49', 0, 1, '2026-07-14 09:12:49');

-- -----------------------------------------------------
-- Table Structure for `tbl_payments`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tbl_payments`;
CREATE TABLE `tbl_payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `or_number` varchar(100) NOT NULL,
  `payment_date` datetime DEFAULT current_timestamp(),
  `treasurer_id` int(11) DEFAULT NULL,
  `payment_status` enum('Unpaid','Paid','Refunded','Exempted') DEFAULT 'Unpaid',
  `payor_name` varchar(255) NOT NULL,
  `receipt_copy` varchar(255) DEFAULT NULL,
  `audit_hash` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  UNIQUE KEY `request_id` (`request_id`),
  UNIQUE KEY `or_number` (`or_number`),
  KEY `treasurer_id` (`treasurer_id`),
  CONSTRAINT `tbl_payments_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `tbl_requests` (`request_id`) ON DELETE CASCADE,
  CONSTRAINT `tbl_payments_ibfk_2` FOREIGN KEY (`treasurer_id`) REFERENCES `tbl_barangayofficials` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data Dump for `tbl_payments`
INSERT INTO `tbl_payments` VALUES 
(13, 8, '0.00', '1234059080', '2026-07-14 10:03:59', 3, 'Exempted', 'John Rey Morales', NULL, NULL);

-- -----------------------------------------------------
-- Table Structure for `tbl_requests`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tbl_requests`;
CREATE TABLE `tbl_requests` (
  `request_id` int(11) NOT NULL AUTO_INCREMENT,
  `resident_id` int(11) NOT NULL,
  `doc_type_id` int(11) NOT NULL,
  `reference_no` varchar(100) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `rejection_reason` text DEFAULT NULL,
  `request_status` enum('Pending','For Verification','For Payment','Processing','Ready for Pickup','Issued','Rejected','Cancelled') DEFAULT 'Pending',
  `date_requested` datetime DEFAULT current_timestamp(),
  `qr_code_string` varchar(255) DEFAULT NULL,
  `pickup_date` datetime DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`request_id`),
  UNIQUE KEY `reference_no` (`reference_no`),
  UNIQUE KEY `qr_code_string` (`qr_code_string`),
  KEY `resident_id` (`resident_id`),
  KEY `doc_type_id` (`doc_type_id`),
  KEY `processed_by` (`processed_by`),
  CONSTRAINT `tbl_requests_ibfk_1` FOREIGN KEY (`resident_id`) REFERENCES `tbl_residents` (`resident_id`) ON DELETE CASCADE,
  CONSTRAINT `tbl_requests_ibfk_2` FOREIGN KEY (`doc_type_id`) REFERENCES `tbl_documenttypes` (`doc_type_id`),
  CONSTRAINT `tbl_requests_ibfk_3` FOREIGN KEY (`processed_by`) REFERENCES `tbl_barangayofficials` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data Dump for `tbl_requests`
INSERT INTO `tbl_requests` VALUES 
(8, 10, 1, 'REQ-20260714-3379', '[FIRST-TIME JOBSEEKER] hkjk', NULL, 'Issued', '2026-07-14 09:49:50', '5d0ddfd3dadcc651bbc9c648c18063f18a750f316f5884d46445cc6f02876820', '2026-07-14 10:05:18', 3),
(9, 10, 2, 'WLK-20260714-9713', 'a', NULL, 'Processing', '2026-07-14 10:30:26', 'a75970bd028c2d038d6177b6e285bfcb9e78f79d507ada93ae59ec9ecf57cca9', NULL, 3),
(10, 9, 1, 'WLK-20260714-5051', 'trabaho', NULL, 'For Payment', '2026-07-14 10:31:50', NULL, NULL, 3),
(11, 10, 3, 'REQ-20260714-9352', 'idawubdauwb', NULL, 'Pending', '2026-07-14 10:32:57', NULL, NULL, NULL);

-- -----------------------------------------------------
-- Table Structure for `tbl_residents`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tbl_residents`;
CREATE TABLE `tbl_residents` (
  `resident_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `date_of_birth` date NOT NULL,
  `civil_status` enum('Single','Married','Widowed','Divorced') NOT NULL,
  `address_street` varchar(255) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `id_proof_image` varchar(255) DEFAULT NULL,
  `account_status` enum('Pending','Active','Blocked') DEFAULT 'Pending',
  `require_password_change` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`resident_id`),
  UNIQUE KEY `email_address` (`email_address`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data Dump for `tbl_residents`
INSERT INTO `tbl_residents` VALUES 
(1, 'test', NULL, 'testt', '2019-12-31 16:00:00', 'Single', 'kahit saan', 'test@gmail.com', '7d5390daa3c63194f01294d0607e7d67:32ff3ce0a21aa7d92432be3f79acecf78c4d5e16f1f52f16c2977d568e02762d', 'ecd71870d1963316a97e3ac3408c9835ad8cf0f3c1bc703527c30265534f75ae', 'secure_dummy_id_12345.enc', 'Active', 0),
(2, 'Aether', 'M.', 'Akuma', '2026-03-21 16:00:00', 'Single', 'Road 13 Pasong Malapad G.S.I.S. Hills Talipapa Caloocan City', 'test1@gmail.com', 'c0785a7e07b7201d3f11e09503f2f152:15a97367daa8eb25ed9a10f5035960f0', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', 'idproof_2_1774598978782-968239353.jpg.enc', 'Active', 0),
(3, 'Aether', 'M.', 'Akuma', '2026-03-21 16:00:00', 'Single', 'Road 13 Pasong Malapad G.S.I.S. Hills Talipapa Caloocan City', 'test3@gmail.com', 'e0d5889f2e4dd7018712a7b5b889b1a0:61568b82807534388fc6fd800b77729c', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', NULL, 'Pending', 0),
(4, 'Aether', 'M.', 'Akuma', '2026-03-21 16:00:00', 'Single', 'Road 13 Pasong Malapad G.S.I.S. Hills Talipapa Caloocan City', 'test4@gmail.com', '7bf3400acf0a391606543e688661f4d4:dca9773f3fdf091e8d5faa12e3deb16d', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', NULL, 'Pending', 0),
(5, 'Aether', 'M.', 'Akuma', '2026-03-21 16:00:00', 'Single', 'Road 13 Pasong Malapad G.S.I.S. Hills Talipapa Caloocan City', 'test5@gmail.com', 'b65dd9112d85dd3f2a27042574c31009:f3149400f3288446ed6e68af006c3fb1', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', NULL, 'Pending', 0),
(6, 'Aether', NULL, 'Akuma', '1984-12-31 16:00:00', 'Single', 'asfdasfgawrgawda', 'test67@gmail.com', '999cfabc96ef1ef876318193c3e50ba2:9b915bab412587c257e4f308ea113d7d', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', NULL, 'Pending', 0),
(9, 'reyrey', 'reyrey', 'reyrey', '2002-12-07 16:00:00', 'Single', 'dito lang malapit sainyo', 'test2@gmail.com', 'f78df1dce41f54914a854657c8b0c48b:1a495eb6294a4a19611f40d35a5ccd28', '6fec2a9601d5b3581c94f2150fc07fa3d6e45808079428354b868e412b76e6bb', 'idproof_9_1784011073804-37189870.png.enc', 'Active', 0),
(10, 'John', NULL, 'Rey Morales', '2003-11-07 16:00:00', 'Single', 'dyan lang', 'morales.johnrey@gmail.com', '629a95b74b57980fa31c77fcfc132e00:aa2c1c0de693c3338eb7916ebe420591', 'ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f', 'idproof_10_1784025177764-967237526.jpg.enc', 'Active', 0);

-- -----------------------------------------------------
-- Table Structure for `tbl_systemsettings`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tbl_systemsettings`;
CREATE TABLE `tbl_systemsettings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `data_type` enum('String','Boolean','Integer','JSON') DEFAULT 'String',
  `is_encrypted` tinyint(1) DEFAULT 0,
  `last_updated` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `updated_by` (`updated_by`),
  CONSTRAINT `tbl_systemsettings_ibfk_1` FOREIGN KEY (`updated_by`) REFERENCES `tbl_barangayofficials` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data Dump for `tbl_systemsettings`
INSERT INTO `tbl_systemsettings` VALUES 
(1, 'barangay_name', 'Barangay Malaya', 'The official name of the barangay', NULL, 'String', 0, '2026-07-14 10:43:25', 3),
(2, 'contact_email', 'admin@brgy143.gov.ph', 'Public contact email', NULL, 'String', 0, '2026-02-24 09:24:55', NULL);

SET FOREIGN_KEY_CHECKS = 1;
